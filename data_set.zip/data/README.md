# This folder contains the data for the paper *Organization and Opinion Extraction in Public Comments and Legislator Engagement Tracking*

Please note that all transcripts were derived from publically accessible California State Legislatures hearing videos.

## engagement_absentee_data

This folder contains the data neccessary to demonstrate absentee and engagement calculations. It includes
hearing CSVs (discussion_*.csv) from the database used in the paper which are used to calculate hearing level statistics. 

discussion_people_list.csv is a per-hearing list of legislators that are on the committee the hearing takes place, this is neccessary to determine what legislators are absent.

full_people_list is a list of all individuals in the database, and this is neccessary to determine what roles the speakers in the discussion transcript have, so general public members can be excluded from the calculations.

## affiliation_statistics.csv

This file contains the raw data used to calculate the organizations that most frequently interact with hearings through the public comment section. The data is taken from the California Legislative session from 2017-2018. Each hearing is a row in the CSV. The second column contains the list of affiliates who commented on the hearing. The fifth column is the type of hearing, the sixth column is the date of the hearing, and the 7th column is the hearing date. The ninth column dictates if the hearing was in the house or assembly

## california_cities.csv and Organizations.csv

This is used in the affililiate tracker to remove entites that are identified by the NER model as organizations, when they're really just cities in California. It includes city names, the state they're in, and the county they're in. It is the subset of cities in California from this list: https://github.com/grammakov/USA-cities-and-states

## engagement_statistics.csv

This file contains the raw data used to calculate the legislator engagement. The data is taken from the California Legislative session from 2017-2018. Each hearing is a row in the CSV. There is a column per variable used to calculate engagement, and each of these columns is a dictionary that contains each legislator's score in that category for the hearing.

## legislator_ranked_by_engagement.txt

This is the full rankings of the California State Legislators in the 2017-2018 session of the California State Legislature by their engagement score. This table only includes legislators for whom statistics could be generated. It is derived from engagement_statistics.csv, and the most and least engaged tabled included in the paper are a subset of these rankings.

## Organizations.csv

This is a list of Organizations who were active in the State Legislatures. It is used to generate training data, and to improve the organizational affiliation extraction performance. The list is from the following paper https://dh-abstracts.library.cmu.edu/works/2221

## ranked_affiliates.txt

This is a list of the 100 affiliates who commented on the most hearings from the 2017-2018 session of the California State Legislature. It is derived from affiliation_statistics.csv, and the table included in the paper is a subset of these rankings.

## testing_data.csv

This file contains the hand annotated data neccessary to test the Stanford NER, SpaCy NER models, and the combined system, and to test the position tracker. It contains a list of the affiliated organizations, position of the comment, the text of the comment, and additional metadata.

## training_data.csv

This contains the hand annotated data neccessary to train the Stanford NER and SpaCy NER models. This data is also used to train the position tracker. It contains a list of the affiliated organizations, position of the comment, the text of the comment, and additional metadata.